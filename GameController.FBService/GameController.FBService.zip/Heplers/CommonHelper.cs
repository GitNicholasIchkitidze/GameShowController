﻿// Heplers/RedisTtlProvider.cs
using GameController.FBService.Models;
using Microsoft.Extensions.Options;

namespace GameController.FBService.Heplers
{
	public interface ICommonHelper
    {
		Boolean IsThisMe(string id);

    }

	public class CommonHelper : ICommonHelper
    {
		private readonly VotingOptions _voting;

		public CommonHelper()
		{
			
		}

        public bool IsThisMe(string id)
        {
            return id == "7176465872405704";
        }


	}
}
