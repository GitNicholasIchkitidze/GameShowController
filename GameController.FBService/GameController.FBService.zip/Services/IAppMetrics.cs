﻿namespace GameController.FBService.Services
{

		public interface IAppMetrics
		{
			long IngressCount { get; }
			long EnqueueOk { get; }
			long EnqueueDropped { get; }
			long Dequeued { get; }
			long ProcessedOk { get; }
			long ProcessedFailed { get; }
			long GarbageMessages { get; }
			long NotInTimeUserMessages { get; }

			void IncIngress();
			void IncEnqueueOk();
			void IncEnqueueDropped();
			void IncDequeued();
			void IncProcessedOk();
			void IncProcessedFailed();
			void IncGarbageMessages();
			void IncNotInTimeUserMessages();

		object Snapshot();
		object Reset();
	}

}
