﻿
using GameController.FBService.Extensions;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Threading.Channels;

namespace GameController.FBService.Services
{
	public class MessageQueueService : IMessageQueueService
	{
		private readonly ILogger<MessageQueueService> _logger;
		private readonly IAppMetrics _metrics;                 // ADDED
		private readonly Channel<string> _channel;

		// NOTE: In a real app, this would include the connection/client for RabbitMQ/Service Bus.


		// ADDED: counters for monitoring
		private long _depth;
		private long _dropped;

		public long CurrentDepth => Interlocked.Read(ref _depth);
		public long DroppedCount => Interlocked.Read(ref _dropped);
		public int Capacity { get; }
		public MessageQueueService(ILogger<MessageQueueService> logger, IConfiguration configuration, IAppMetrics metrics)
		{
			_logger = logger;
			_metrics = metrics;

			//_channel = Channel.CreateUnbounded<string>(options);


			// ADDED (2025-12): 
			var configuredCapacity = configuration.GetValue<int>("Queue:Capacity", 10000);
			if (configuredCapacity < 1) configuredCapacity = 10000;
			Capacity = configuredCapacity;         

			var options = new BoundedChannelOptions(Capacity)
			{
				SingleWriter = false,
				SingleReader = false,

				// ✅ When full, DROP new items instead of blocking webhook thread/worker producers
				FullMode = BoundedChannelFullMode.DropWrite
				//FullMode = BoundedChannelFullMode.Wait

			};
			_channel = Channel.CreateBounded<string>(options);
			_logger.LogInformationWithCaller($"[QUEUE] BOUNDED channel created. Capacity={Capacity}, FullMode=DropWrite");

		}

		
		public async Task EnqueueMessageAsync_OLD(string messagePayload)    // RENAMED (2025-12): 
		{
			await _channel.Writer.WriteAsync(messagePayload);
			_logger.LogInformationWithCaller($"[QUEUE] Message Enqueued successfully to internal Channel. Size: {messagePayload.Length} bytes.");

		}

		
		public Task EnqueueMessageAsync(string messagePayload)// ADDED (2025-12): 
		{
			///// NOTE: We do NOT block here. If full, it drops (same as TryEnqueueMessage behavior).
			_ = TryEnqueueMessage(messagePayload);
			return Task.CompletedTask;


			if (messagePayload == null) throw new ArgumentNullException(nameof(messagePayload));

			//await _channel.Writer.WriteAsync(messagePayload);
			Interlocked.Increment(ref _depth);

			_logger.LogDebug("[QUEUE] EnqueueMessageAsync wrote payload. Bytes={Bytes}, Depth={Depth}", messagePayload.Length, CurrentDepth);


		}

		public IAsyncEnumerable<string> GetMessagesAsync_Old(CancellationToken cancellationToken)   // RENAMED (2025-12): 
		{
			// Returns the reader for the Worker to consume (Consumer)
			return _channel.Reader.ReadAllAsync(cancellationToken);
		}


		public async IAsyncEnumerable<string> GetMessagesAsync([System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken cancellationToken) // ADDED (2025-12): 
		{
			await foreach (var item in _channel.Reader.ReadAllAsync(cancellationToken))
			{
				Interlocked.Decrement(ref _depth);
				_metrics.IncDequeued(); // ADDED

				yield return item;
			}
		}

		public bool TryEnqueueMessage(string messagePayload)
		{
			if (messagePayload == null)
			{
				Interlocked.Increment(ref _dropped);
				_metrics.IncEnqueueDropped(); // ADDED

				return false;
			}

			// CHANGED: Non-blocking enqueue (critical for webhook fast ACK).
			if (_channel.Writer.TryWrite(messagePayload))
			{
				Interlocked.Increment(ref _depth);
				_metrics.IncEnqueueOk(); // ADDED


				// CHANGED: Avoid INFO log on every message (kills throughput).
				// Enable Debug when you need to inspect queue behavior.
				_logger.LogDebug("[QUEUE] Enqueued payload. Bytes={Size}. Depth={Depth}", messagePayload.Length, CurrentDepth);

				return true;
			}

			Interlocked.Increment(ref _dropped);
			_metrics.IncEnqueueDropped(); // ADDED


			// NOTE: This is a *signal* that you're in peak mode / queue is undersized.
			//_logger.LogWarningWithCaller($"[QUEUE] Queue is full (capacity={Capacity}). Dropping payload. DroppedCount={DroppedCount}");
			return false;
		}

	}
}
